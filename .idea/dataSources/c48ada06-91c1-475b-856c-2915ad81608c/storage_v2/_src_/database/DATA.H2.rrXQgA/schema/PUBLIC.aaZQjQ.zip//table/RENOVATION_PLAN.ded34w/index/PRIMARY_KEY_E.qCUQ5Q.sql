create unique index PRIMARY_KEY_E
    on RENOVATION_PLAN (ID);

