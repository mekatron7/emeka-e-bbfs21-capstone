create unique index PRIMARY_KEY_3B
    on ITEM (ID);

