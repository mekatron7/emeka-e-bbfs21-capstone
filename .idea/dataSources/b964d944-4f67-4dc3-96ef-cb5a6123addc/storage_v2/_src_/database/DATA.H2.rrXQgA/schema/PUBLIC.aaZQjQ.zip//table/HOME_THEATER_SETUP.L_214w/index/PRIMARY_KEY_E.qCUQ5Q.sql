create unique index PRIMARY_KEY_E
    on HOME_THEATER_SETUP (ID);

