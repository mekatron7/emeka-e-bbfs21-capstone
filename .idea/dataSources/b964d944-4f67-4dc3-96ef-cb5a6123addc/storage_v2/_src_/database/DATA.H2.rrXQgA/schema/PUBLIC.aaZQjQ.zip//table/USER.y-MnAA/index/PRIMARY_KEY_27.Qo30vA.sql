create unique index PRIMARY_KEY_27
    on USER (ID);

